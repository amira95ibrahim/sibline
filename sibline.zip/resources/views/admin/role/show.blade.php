{{--
    @extends('layouts.app')

    @section('content')
        admin.role.show template
    @endsection
--}}
