<div class="table-responsive userlist-table">
    
      {!! $dataTable->table() !!}
    
</div>

@push('script')

{!! $dataTable->scripts() !!}
@endpush



