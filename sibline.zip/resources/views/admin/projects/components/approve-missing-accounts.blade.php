<div class="table-responsive userlist-table">
      {!! $dataTable->table(['name' => 'approve-missing-xx']) !!}
    
</div>

@push('script')

{!! $dataTable->scripts() !!}
@endpush



