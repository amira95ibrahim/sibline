<a href="#" onclick="window.open(this.href,'_blank');
    return false;">Review Document </a>
